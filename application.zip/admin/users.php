<?php include 'includes/session.php' ?>
<!DOCTYPE html>
<html lang="en">
<?php include 'includes/header.php' ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <div class="wrapper">

    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
      <img class="animation__shake" src="dist/img/logo.png" alt="SaFaTech" height="60" width="60">
    </div>

    <!-- Navbar -->
    <?php include 'includes/navbar.php' ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include 'includes/slidebar.php' ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">All User</h1>
            </div><!-- /.col -->

          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="col-12">

            <div class="card">

              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>User Name</th>
                      <th>Mobile</th>
                      <th>Email</th>
                      <th>Create On</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $stmt = $conn->prepare("SELECT * FROM users WHERE vendor_id=:ven");
                    $stmt->execute(['ven' => $admin['vendor_id']]);
                    foreach ($stmt as $r) {

                      $status = ($r['status'])? 'Active':'Deactive';

                      echo '<tr>
                          <td>' . $r['name'] . '</td>
                          <td>' . $r['phone'] . '</td>
                          <td>' . $r['email'] . '</td>
                          <td>'.date('d M, Y', strtotime($r['created_at'])).'</td>
                          <td>'.$status.'</td>
                          <td>
                          <a href="new_user.php?id='.$r['id'].'" class="btn btn-success btn-sm"><i class="fas fa-edit"></i> Edit</a>
                          <button type="button" class="btn btn-danger btn-sm del" data-id="'.$r['id'].'"><i class="fas fa-trash"></i> Delete</button>
                          </td>
                          </tr>';
                    }
                    ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

<div class="container d-flex justify-content-center">
    <div id="delete_modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content border-0">
                <div class="modal-body p-0">
                    <div class="card border-0 p-sm-3 p-2 justify-content-center">
                        <div class="card-header pb-0 bg-white border-0 ">
                            <div class="row">
                                <div class="col ml-auto"><button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>
                            </div>
                            <p class="font-weight-bold mb-2"> Are you sure you wanna delete this ?</p>
                            <p class="text-muted "> This will be permanently delete.</p>
                        </div>
                        <div class="card-body px-sm-4 mb-2 pt-1 pb-0">
                            <div class="row justify-content-end no-gutters">
                                <div class="col-auto"><button type="button" class="btn btn-light text-muted" data-dismiss="modal">Cancel</button></div>
                                <form action="add_user.php" method="post">
                                <input type="hidden" id="delid" name="id">
                                <div class="col-auto"><button type="submit" class="btn btn-danger px-4" name="del">Delete</button></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    
    <?php include 'includes/footer.php' ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <?php include 'includes/js.php' ?>
  <script>
    $(function() {
      $("#example1").DataTable({
        "responsive": true, "lengthChange": true, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
      // $('#example1').DataTable({
      //   "paging": true,
      //   "lengthChange": false,
      //   "searching": false,
      //   "ordering": true,
      //   "info": true,
      //   "autoWidth": false,
      //   "responsive": true,
      // });
    });
    
    $(document).on('click', '.del', function() {
        var id = $(this).data('id');
        $('#delid').val(id);
        $('#delete_modal').modal('show');
    });
    
    var title = $('#ccn').val();
    document.title = title+'Users';

    document.getElementById("nav_user").classList.add("menu-open");
    document.getElementById("l_user").classList.add("active");

  </script>
</body>

</html>