<?php
include 'includes/session.php';

if(isset($_POST['add'])){


    $name = $_POST['name'];
    $unit = $_POST['unit'];
    $min_qty = $_POST['min_qty'];
    $barcode = $_POST['barcode'];
    $category = $_POST['category'];
    $in_price = $_POST['in_price'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $tax = $_POST['tax'];
    $sku = $_POST['sku'];
    $lot = $_POST['lot'];
    $desc = $_POST['desc'];
    $hsn = $_POST['hsn'];
    $exp = $_POST['exp'];
    $tax_type = $_POST['tax_type'];
    $profit = $_POST['profit'];
    $note = $_POST['note'];
    


        $file = '';
        $profile =$_FILES['icon']['name'];

        if(!empty($profile)){
            $time = time();
            $ext = pathinfo($profile, PATHINFO_EXTENSION);
            $file = $time.'.'.$ext;
            $dir = "../images/items/";
            $target_file = $dir . basename($file);
            move_uploaded_file($_FILES["icon"]["tmp_name"], $target_file);
        }

        $stmt = $conn->prepare("INSERT INTO `products`(`name`, `code`, `category`, `unit`, `qty`, `min_qty`, `in_price`, `price`, `tax`, `sku`, `lot`, `description`, `hsn`, `exp_date`, `tax_type`, `profit`, `note`, `icon`, `create_by`, `vendor_id`) VALUES 
        (:name, :code, :category, :unit, :qty, :min_qty, :in, :price, :tax, :sku, :lot, :desc, :hsn, :exp, :tax_type, :profit, :note, :icon, :cre, :ven)");
        $stmt->execute(['name'=>$name, 'code'=>$barcode, 'category'=>$category, 'unit'=>$unit, 'qty'=>$stock, 'min_qty'=>$min_qty, 'in'=>$in_price, 'price'=>$price, 'tax'=>$tax, 'sku'=>$sku, 'lot'=>$lot, 'desc'=>$desc, 
        'hsn'=>$hsn, 'exp'=>$exp, 'tax_type'=>$tax_type, 'profit'=>$profit, 'note'=>$note, 'icon'=>$file, 'cre'=>$admin['name'], 'ven'=>$admin['vendor_id']]);

        $_SESSION['success'] = 'Add new item';

}elseif(isset($_POST['edit'])){

    $id = $_POST['id'];
    $name = $_POST['name'];
    $unit = $_POST['unit'];
    $min_qty = $_POST['min_qty'];
    $barcode = $_POST['barcode'];
    $category = $_POST['category'];
    $in_price = $_POST['in_price'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $tax = $_POST['tax'];
    $sku = $_POST['sku'];
    $lot = $_POST['lot'];
    $desc = $_POST['desc'];
    $hsn = $_POST['hsn'];
    $exp = $_POST['exp'];
    $tax_type = $_POST['tax_type'];
    $profit = $_POST['profit'];
    $note = $_POST['note'];
    


        $file = '';
        $profile =$_FILES['icon']['name'];

        if(!empty($profile)){
            $time = time();
            $ext = pathinfo($profile, PATHINFO_EXTENSION);
            $file = $time.'.'.$ext;
            $dir = "../images/items/";
            $target_file = $dir . basename($file);
            move_uploaded_file($_FILES["icon"]["tmp_name"], $target_file);
        }

        $stmt = $conn->prepare("UPDATE `products` SET `name`=:name, `code`=:code, `category`=:category, `unit`=:unit, `qty`=:qty, `min_qty`=:min_qty, `in_price`=:in, `price`=:price, `tax`=:tax, `sku`=:sku, `lot`=:lot, `description`=:desc, 
        `hsn`=:hsn, `exp_date`=:exp, `tax_type`=:tax_type, `profit`=:profit, `note`=:note, `icon`=:icon, `create_by`=:cre, `vendor_id`=:ven WHERE id=:id");
        $stmt->execute(['name'=>$name, 'code'=>$barcode, 'category'=>$category, 'unit'=>$unit, 'qty'=>$stock, 'min_qty'=>$min_qty, 'in'=>$in_price, 'price'=>$price, 'tax'=>$tax, 'sku'=>$sku, 'lot'=>$lot, 'desc'=>$desc, 
        'hsn'=>$hsn, 'exp'=>$exp, 'tax_type'=>$tax_type, 'profit'=>$profit, 'note'=>$note, 'icon'=>$file, 'cre'=>$admin['name'], 'ven'=>$admin['vendor_id'], 'id'=>$id]);
        

        $_SESSION['success'] = 'Item Updated';
}elseif(isset($_POST['del'])){
    
    $id = $_POST['id'];
    $stmt = $conn->prepare("DELETE FROM `products` WHERE id=:id");
    $stmt->execute(['id'=>$id]);
    $_SESSION['success'] = 'Deleted';
}

header("Location: products.php");
?>