<?php
include '../includes/conn.php';
session_start();
if(!isset($_SESSION['admin']) || trim($_SESSION['admin']) == ''){
    header('location: ../index.php');
    exit();
}

$conn = $pdo->open();

$stmt = $conn->prepare("SELECT * FROM users WHERE id=:ven");
$stmt->execute(['ven'=>$_SESSION['admin']]);
$admin = $stmt->fetch();

$stmt = $conn->prepare("SELECT * FROM vendors WHERE id=:id");
$stmt->execute(['id'=>$admin['vendor_id']]);
$vd = $stmt->fetch();

$pdo->close();
$cur = '$';
$pro_pic= ($admin['profile'])?'../images/'.$admin['profile'].'':'dist/img/user2-160x160.jpg';

?>