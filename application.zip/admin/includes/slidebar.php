<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <img src="dist/img/logo.png" alt="VBP Websoft" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">VBP Websoft</span>
        <input type="hidden" id="ccn" value="VBP Websoft | ">
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo $pro_pic ?>" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo $admin['name'] ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
                <li class="nav-item">
                    <a href="index.php" class="nav-link" id="nav_dashboard">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard

                        </p>
                    </a>
                </li>


                <li class="nav-item" id="nav_item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fab fa-product-hunt"></i>
                        <p>
                            Products
                            <i class="fas fa-angle-left right"></i>
                            <span class="badge badge-info right"></span>
                        </p>
                    </a>
                    <ul class="nav nav-treeview ml-3">
                        <li class="nav-item">
                            <a id="l_add_item" href="new_product.php" class="nav-link">
                                <i class="far fa-plus-square"></i>
                                <p>New Product</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a id="l_item" href="products.php" class="nav-link">
                                <i class="fas fa-list "></i>
                                <p>Product List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a id="l_add_category" href="new_category.php" class="nav-link">
                                <i class="far fa-plus-square"></i>
                                <p>New Category</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a id="l_category" href="category.php" class="nav-link">
                                <i class="fas fa-list "></i>
                                <p>Category List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a id="l_add_unit" href="new_unit.php" class="nav-link">
                                <i class="far fa-plus-square"></i>
                                <p>New Unit</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a id="l_unit" href="units.php" class="nav-link">
                                <i class="fas fa-list "></i>
                                <p>Unit List</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item" id="nav_module">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-weight-hanging"></i>
                        <p>
                            Module
                            <i class="fas fa-angle-left right"></i>
                            <span class="badge badge-info right"></span>
                        </p>
                    </a>
                    <ul class="nav nav-treeview ml-3">
                        <li class="nav-item">
                            <a id="l_add_module" href="new_module.php" class="nav-link">
                                <i class="far fa-plus-square"></i>
                                <p>New Module</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a id="l_module" href="modules.php" class="nav-link">
                                <i class="fas fa-list "></i>
                                <p>Module List</p>
                            </a>
                        </li>

                    </ul>
                </li>

         
                <li class="nav-item" id="nav_role">
                    <a href="#" class="nav-link">
                        <i class="nav-icon far fa-user"></i>
                        <p>
                            Roles
                            <i class="fas fa-angle-left right"></i>
                            <span class="badge badge-info right"></span>
                        </p>
                    </a>
                    <ul class="nav nav-treeview ml-3">
                        <li class="nav-item">
                            <a id="l_add_role" href="new_role.php" class="nav-link">
                                <i class="far fa-plus-square"></i>
                                <p>New Role</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a id="l_role" href="roles.php" class="nav-link">
                                <i class="fas fa-list "></i>
                                <p>Role List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a id="l_role_per" href="role_permission.php" class="nav-link">
                                <i class="fas fa-list "></i>
                                <p>Role Permission</p>
                            </a>
                        </li>

                    </ul>
                </li>
                
                <li class="nav-item" id="nav_user">
                    <a href="#" class="nav-link">
                        <i class="nav-icon far fa-user"></i>
                        <p>
                            Users
                            <i class="fas fa-angle-left right"></i>
                            <span class="badge badge-info right"></span>
                        </p>
                    </a>
                    <ul class="nav nav-treeview ml-3">
                        <li class="nav-item">
                            <a id="l_add_user" href="new_user.php" class="nav-link">
                                <i class="far fa-plus-square"></i>
                                <p>New User</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a id="l_user" href="users.php" class="nav-link">
                                <i class="fas fa-list "></i>
                                <p>User List</p>
                            </a>
                        </li>

                    </ul>
                </li>


                <!-- <li class="nav-header">EXAMPLES</li> -->
                <li class="nav-item">
                    <a href="../logout.php" class="nav-link" id="nav_dashboard">
                        <i class="nav-icon fas fa-power-off"></i>
                        <p>
                           Logout
                        </p>
                    </a>
                </li>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>