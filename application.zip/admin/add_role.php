<?php include 'includes/session.php';

if(isset($_POST['add'])){

    $name = $_POST['name'];
    $desc = $_POST['desc'];

    $stmt = $conn->prepare("INSERT INTO `roles` (`name`, `description`, `create_by`, `vendor_id`) VALUES (:name, :desc, :cre, :ven)");
    $stmt->execute(['name'=>$name, 'desc'=>$desc, 'cre'=>$admin['name'], 'ven'=>$admin['vendor_id']]);

    $_SESSION['success'] = 'Add new role';

}elseif(isset($_POST['edit'])){

    $name = $_POST['name'];
    $desc = $_POST['desc'];
    $id = $_POST['id'];

    $stmt = $conn->prepare("UPDATE `roles` SET `name`=:name, `description`=:desc WHERE id=:id");
    $stmt->execute(['name'=>$name, 'desc'=>$desc, 'id'=>$id]);

    $_SESSION['success'] = 'Role Updated';

}elseif(isset($_POST['del'])){

    $id = $_POST['id'];

    $stmt = $conn->prepare("DELETE FROM `roles` WHERE id=:id");
    $stmt->execute(['id'=>$id]);

    $_SESSION['success'] = 'Deleted';

}


header("Location: roles.php")
?>