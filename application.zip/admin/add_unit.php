<?php include 'includes/session.php';

if(isset($_POST['add'])){

    $name = $_POST['name'];

    $stmt = $conn->prepare("INSERT INTO `units`(`name`, `vendor_id`) VALUES (:name, :ven)");
    $stmt->execute(['name'=>$name, 'ven'=>$admin['vendor_id']]);

    $_SESSION['success'] = 'Add new unit';

}elseif(isset($_POST['edit'])){

    $name = $_POST['name'];
    $id = $_POST['id'];

    $stmt = $conn->prepare("UPDATE units SET name=:name WHERE id=:id");
    $stmt->execute(['name'=>$name, 'id'=>$id]);

    $_SESSION['success'] = 'Unit Updated';

}elseif(isset($_POST['del'])){

    $id = $_POST['id'];

    $stmt = $conn->prepare("DELETE FROM `units` WHERE id=:id");
    $stmt->execute(['id'=>$id]);

    $_SESSION['success'] = 'Deleted';

}

header("Location: units.php");
?>