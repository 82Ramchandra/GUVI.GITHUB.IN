<?php include 'includes/session.php';

if(isset($_POST['add'])){

}

if(isset($_POST['add'])){

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $pass = $_POST['pass'];

    $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE email=:email");
    $stmt->execute(['email'=>$email]);
    $u = $stmt->fetch();

    if($u['COUNT(*)'] == 0){

        $file = '';
        $profile =$_FILES['profile']['name'];

        if(!empty($profile)){
            $time = time();
            $ext = pathinfo($profile, PATHINFO_EXTENSION);
            $file = $time.'.'.$ext;
            $dir = "../images/";
            $target_file = $dir . basename($file);
            move_uploaded_file($_FILES["profile"]["tmp_name"], $target_file);
        }

        $password = password_hash($pass, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO `users`(`name`, `phone`, `email`, `profile`, `role`, `password`, `create_by`, `vendor_id`) VALUES 
        (:name, :phone, :email, :profile, :role, :pass, :cre, :ven)");
        $stmt->execute(['name'=>$name, 'phone'=>$phone, 'email'=>$email, 'profile'=>$file, 'role'=>$role, 'pass'=>$password, 'cre'=>$admin['name'], 'ven'=>$admin['vendor_id']]);
        
    }

    $_SESSION['success'] = 'Add new user';

}elseif(isset($_POST['edit'])){

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    $id = $_POST['id'];

    $stmt = $conn->prepare("UPDATE `users` SET `name`=:name, `phone`=:phone, `email`=:email, `role`=:role WHERE id=:id");
    $stmt->execute(['name'=>$name, 'phone'=>$phone, 'email'=>$email, 'role'=>$role, 'id'=>$id]);

    $_SESSION['success'] = 'User Updated';

}elseif(isset($_POST['del'])){

    $id = $_POST['id'];

    $stmt = $conn->prepare("DELETE FROM `users` WHERE id=:id");
    $stmt->execute(['id'=>$id]);

    $_SESSION['success'] = 'Deleted';

}


header("Location: users.php")
?>