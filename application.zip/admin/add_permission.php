<?php include 'includes/session.php';

/*echo "<pre>";
print_r($_POST);
echo "</pre>";
exit();*/
if(!empty($_POST)):
    foreach($_POST as $post):
        $stmt1 = $conn->prepare("SELECT * FROM module");
        $stmt1->execute();
        $modules_arr=$stmt1->fetchAll();
        
        $stmt2 = $conn->prepare("SELECT * FROM role_permission WHERE role_id=:role_id and module_id=:module_id");
        $stmt2->execute(['role_id'=>explode("-",$post)[1], 'module_id'=>explode("-",$post)[0]]);
        $my_arr=$stmt2->fetchAll();
        
        if(empty($my_arr)):
            $stmt = $conn->prepare("INSERT INTO `role_permission` (`role_id`, `module_id`) VALUES (:role_id, :module_id)");
            $stmt->execute(['role_id'=>explode("-",$post)[1], 'module_id'=>explode("-",$post)[0]]);
        endif;
    endforeach;
endif;

/*if(isset($_POST['add'])){

    $name = $_POST['name'];
    $desc = $_POST['desc'];

    $stmt = $conn->prepare("INSERT INTO `category` (`name`, `description`, `create_by`, `vendor_id`) VALUES (:name, :desc, :cre, :ven)");
    $stmt->execute(['name'=>$name, 'desc'=>$desc, 'cre'=>$admin['name'], 'ven'=>$admin['vendor_id']]);

    $_SESSION['success'] = 'Add new category';

}elseif(isset($_POST['edit'])){

    $name = $_POST['name'];
    $desc = $_POST['desc'];
    $id = $_POST['id'];

    $stmt = $conn->prepare("UPDATE `category` SET `name`=:name, `description`=:desc WHERE id=:id");
    $stmt->execute(['name'=>$name, 'desc'=>$desc, 'id'=>$id]);

    $_SESSION['success'] = 'Category Updated';

}elseif(isset($_POST['del'])){

    $id = $_POST['id'];

    $stmt = $conn->prepare("DELETE FROM `category` WHERE id=:id");
    $stmt->execute(['id'=>$id]);

    $_SESSION['success'] = 'Deleted';

}*/

header("Location: role_permission.php");
?>