<?php include 'includes/session.php';

if(isset($_GET['id'])){

    $stmt = $conn->prepare("SELECT * FROM users WHERE id=:id");
    $stmt->execute(['id'=>$_GET['id']]);
    $r = $stmt->fetch();
    $myrole=$r['role'];
}

?>
<!DOCTYPE html>
<html lang="en">
<?php include 'includes/header.php' ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">

        <!-- Preloader -->
        <div class="preloader flex-column justify-content-center align-items-center">
            <img class="animation__shake" src="dist/img/logo.png" alt="SaFaTech" height="60" width="60">
        </div>

        <!-- Navbar -->
        <?php include 'includes/navbar.php' ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php include 'includes/slidebar.php' ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Create User</h1>
                        </div><!-- /.col -->

                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="col-12">

                        <div class="card">

                            <div class="card-body">
                                <form action="add_user.php" method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="name" class="col-sm-4 control-label">User Name<label class="text-danger">*</label></label>

                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" value="<?php if(isset($_GET['id'])) {echo $r['name'];} ?>" name="name" required>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="name" class="col-sm-4 control-label">Mobile<label class="text-danger">*</label></label>

                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" value="<?php if(isset($_GET['id'])) {echo $r['name'];} ?>" name="phone" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="name" class="col-sm-4 control-label">Email<label class="text-danger">*</label></label>

                                            <div class="col-sm-8">
                                                <input type="email" class="form-control" value="<?php if(isset($_GET['id'])) {echo $r['name'];} ?>" name="email" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="name" class="col-sm-4 control-label">Role<label class="text-danger">*</label></label>

                                            <div class="col-sm-8">
                                                <select class="form-control" name="role" required>
                                                    <option value="">--Select--</option>
                                                    <?php

                                                        $stmt = $conn->prepare("SELECT * FROM roles WHERE vendor_id=:ven");
                                                        $stmt->execute(['ven'=>$admin['vendor_id']]);
                                                        foreach($stmt as $r){
                                                            if(isset($_GET['id'])):
                                                                if($r['id']==$myrole):
                                                                    echo '<option selected value="'.$r['id'].'">'.$r['name'].'</option>';
                                                                else:
                                                                    echo '<option value="'.$r['id'].'">'.$r['name'].'</option>';
                                                                endif;
                                                            else:
                                                                echo '<option value="'.$r['id'].'">'.$r['name'].'</option>';
                                                            endif;
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <?php if(!isset($_GET['id'])):?>
                                        <div class="form-group">
                                            <label for="name" class="col-sm-4 control-label">Password<label class="text-danger">*</label></label>

                                            <div class="col-sm-8">
                                                <input type="password" class="form-control" name="pass" required>
                                            </div>
                                        </div>
                                        <?php endif;?>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <input type="file" class="form-control" name="profile">
                                        </div>

                                        <img src="https://shop.safatech.in/theme/dist/img/avatar5.png" alt="profilr">
                                    </div>

                                </div>

                                <div class="row mt-3 justify-content-end">
                                    <?php
                                    if(isset($_GET['id'])){
                                        echo '<div class="col-md-2">
                                        <button type="submit" class="btn btn-block btn-primary" name="edit">Update</button>
                                        </div>';
                                    }else{
                                    echo '<div class="col-md-2">
                                        <button type="submit" class="btn btn-block btn-primary" name="add">Save</button>
                                        </div>';
                                    }
                                    ?>
                                </div>
                                </form>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php include 'includes/footer.php' ?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <?php include 'includes/js.php' ?>
    <script>
        $('.select2').select2()
        var title = $('#ccn').val();
        document.title = title+'New User';
        document.getElementById("nav_user").classList.add("menu-open");
        document.getElementById("l_add_user").classList.add("active");
    </script>
</body>

</html>