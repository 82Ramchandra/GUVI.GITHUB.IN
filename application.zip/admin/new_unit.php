<?php include 'includes/session.php';

if(isset($_GET['id'])){

    $stmt = $conn->prepare("SELECT * FROM units WHERE id=:id");
    $stmt->execute(['id'=>$_GET['id']]);
    $r = $stmt->fetch();
}

?>
<!DOCTYPE html>
<html lang="en">
<?php include 'includes/header.php' ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">

        <!-- Preloader -->
        <div class="preloader flex-column justify-content-center align-items-center">
            <img class="animation__shake" src="dist/img/logo.png" alt="SaFaTech" height="60" width="60">
        </div>

        <!-- Navbar -->
        <?php include 'includes/navbar.php' ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php include 'includes/slidebar.php' ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">New Unit</h1>
                        </div><!-- /.col -->

                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="col-12">

                        <div class="card">

                            <div class="card-body">
                                <form action="add_unit.php" method="post">
                                    <input type="hidden" name="id" value="<?php echo $r['id'] ?>" >
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="form-group">
                                                <label for="name" class="col-sm-4 control-label">Unit Name<label class="text-danger">*</label></label>

                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="name" value="<?php if(isset($_GET['id'])) {echo $r['name'];} ?>" placeholder="Enter Unit Name" required>
                                                </div>
                                            </div>
                                            
                                        </div>

                                    </div>

                                    <div class="row mt-3 justify-content-end">
                                        <?php
                                        if(isset($_GET['id'])){
                                            echo '<div class="col-md-2">
                                            <button type="submit" class="btn btn-block btn-primary" name="edit">Update</button>
                                            </div>';
                                        }else{
                                        echo '<div class="col-md-2">
                                            <button type="submit" class="btn btn-block btn-primary" name="add">Save</button>
                                            </div>';
                                        }
                                        ?>
                                    </div>
                                </form>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php include 'includes/footer.php' ?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <?php include 'includes/js.php' ?>
    <script>
        $('.select2').select2()
        var title = $('#ccn').val();
        document.title = title+'New Unit';
        document.getElementById("nav_item").classList.add("menu-open");
        document.getElementById("l_add_unit").classList.add("active");
    </script>
</body>

</html>